'use strict';
const express = require('express')
const app = express()
const path = require('path')
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser');
const session = require('express-session');
const popup = require('window-popup').windowPopup;
app.use(express.static('public'))
app.set('view engine', 'ejs')
app.set('views', path.join(__dirname,'views') )
app.use(bodyParser.urlencoded({ extended: false }))
app.use(session({ resave: true ,secret: 'helloooWorldddd' , saveUninitialized: true}));
const fs = require('fs');

app.get('/',function(req,res){
    res.render('login',{
        
    })
})
app.post('/',function(req,res){
    req.session.user = req.body.username
    req.session.pass = req.body.password
    req.session.found = false;
    let x = fs.readFileSync('MyDataBase.JSON');
    if(x.length!=0)
    {
        let y = JSON.parse(x)
        for(var i = 0 ; i < y.length ; i++)
        {
            
            if(y[i].name == req.session.user)
            {
                if(y[i].pass == req.session.pass)
                {
                    req.session.found = true;
                    break;
                }
            }
        }
        if(req.session.found)
        {

            req.session.user = y[i].name
            //users = y[i].name
            req.session.passwords = y[i].pass
            res.redirect('home')
            req.session.found = false; 

        }
        else
        {
            res.redirect('LoginError')
        
        }
    
    }
    else{
        res.redirect('LoginError')
    }
})

app.get('/login',function(req,res){
    res.render('login',{
        
    })
})
app.post('/Login',function(req,res){
    req.session.found = false
    req.session.user = req.body.username
    req.session.pass = req.body.password
    let x = fs.readFileSync('MyDataBase.JSON');
    if(x.length!=0)
    {
        let y = JSON.parse(x)
        for(var i = 0 ; i < y.length ; i++)
        {
            
            if(y[i].name == req.session.user)
            {
                if(y[i].pass == req.session.pass)
                {
                    req.session.found = true;
                    break;
                }
            }
        }
        if(req.session.found==true)
        {
            req.session.user = y[i].name
            req.session.passwords = y[i].pass
            res.redirect('home') 
            req.session.found = false;  
        }
        else{
            if(req.session.found==false){
            res.redirect('LoginError')
            }
        }
    
    }
    else{
        res.redirect('LoginError')
    }
    
})
app.get('/LoginError',function(req,res){
    res.render('LoginError')
})

//Registration

app.get('/registration',function(req,res){
    res.render('registration')
})

app.post('/register',function(req,res){
    req.session.notFound = true;
    req.session.user = req.body.username
    req.session.pass = req.body.password
    if(req.session.user.length!=0 && req.session.pass.length!=0)
    {
        var yy = [{
            name: req.session.user ,
            pass: req.session.pass,
            watch: []
        }]
        let x = fs.readFileSync('MyDataBase.JSON');
        if(x.length!=0)
        {
            let y = JSON.parse(x)
            for(var i = 0 ; i < y.length ; i++)
            {
                if(y[i].name == req.session.user)
                {
                    req.session.notFound = false;
                    break;
                }
            }
            if(req.session.notFound)
            {
             res.redirect('RegistrationSuccess')
             var conc = y.concat(yy);
             fs.writeFile('MyDataBase.JSON',JSON.stringify(conc),finished);
             
                
            }
            else
            {
                if(!req.session.notFound){
                    res.redirect('RegisterError')
                    req.session.notFound = true;
                }
            }
        
        }
        else{
            
            fs.writeFile('MyDataBase.JSON',JSON.stringify(yy),finished) 
            res.redirect('RegistrationSuccess')
        }
    }
    else{
        res.redirect('RegisterError')
    }
    
})
app.get('/RegisterError',function(req,res){
    res.render('RegisterError')
})
app.get('/RegistrationSuccess',function(req,res) {
    res.render('RegistrationSuccess')
})

//Home page
app.get('/home',function(req,res){
    res.render('home')
})

// Drama from home page
app.get('/drama',function(req,res){
    res.render('drama')
})


//Horror from home page
app.get('/horror',function(req,res){
    res.render('horror')
})


//Action from home page
app.get('/action',function(req,res){
    res.render('action')
})


// My Watchlist from home page

app.get('/watchlist',function(req,res){
    var myWatchList = getWatchlist(req.session.user,req.session.passwords);
    res.render('watchlist',{
        myWatchList: myWatchList
    })
})

app.get('/RemovedFromWatchlist',function(req,res){
    res.render('RemovedFromWatchlist')
})


app.post('/openWatchlist',function(req,res){
    res.redirect('watchlist');
})
app.post('/goToWatchlist',function(req,res) {
    res.redirect('watchlist');
    getWatchlist(req.session.user,req.session.passwords);
})

app.get('/AddedWatchlist',function(req,res) {
    res.render('AddedWatchlist')
})

// Search bar

app.get('/search',function(req,res){
    res.render('searchresults')
})

app.get('/searchresults',function(req,res){
     
    var last = getSearch(req.session.search)
    res.render('searchresults',{
        last : last
    })
})

app.post('/search',function(req,res){
    req.session.search = req.body.Search;
    req.session.search = req.session.search.replace(/ /g,'');
    res.redirect('searchresults')
    
})

app.get('/notFound',function(req,res)
{
    res.render('notFound')
})

app.get('/alreadyFound',function(req,res)
{
    res.render('alreadyFound')
})


// The god father

app.get('/godfather',function(req,res){
    res.render('godfather')
})
app.post('/godfather',function(req,res){

    req.session.godfather = Check(req.session.user,req.session.passwords,"godfather")
    var flag = req.session.godfather
    if(flag)
    {
        res.redirect('alreadyFound')
    }
    else
    {
        res.redirect('AddedWatchlist')
    }
})

app.post('/godfatherR',function(req,res){

    deleteFromWatch(req.session.user,req.session.passwords,"godfather")
    res.redirect('RemovedFromWatchlist')

})

//The god father 2

app.get('/godfather2',function(req,res){
    res.render('godfather2')
    
})

app.post('/godfather2',function(req,res){

    req.session.godfather2 = Check(req.session.user,req.session.passwords,"godfather2")
    var flag = req.session.godfather2
    if(flag)
    {
        res.redirect('alreadyFound')
    }
    else
    {
        res.redirect('AddedWatchlist')
    }
})

app.post('/godfather2R',function(req,res){

    deleteFromWatch(req.session.user,req.session.passwords,"godfather2")
    res.redirect('RemovedFromWatchlist')

})



//Scream 

app.get('/scream',function(req,res){
    res.render('scream')
})
app.post('/scream',function(req,res){
    
    req.session.scream = Check(req.session.user,req.session.passwords,"scream")
    var flag = req.session.scream
    if(flag)
    {
        res.redirect('alreadyFound')
    }
    else
    {
        res.redirect('AddedWatchlist')
    }
})
app.post('/screamR',function(req,res){

    deleteFromWatch(req.session.user,req.session.passwords,"scream")
    res.redirect('RemovedFromWatchlist')

})

//Conjuring

app.get('/conjuring',function(req,res){
    res.render('conjuring')
})
app.post('/conjuring',function(req,res){
    
    req.session.conjuring = Check(req.session.user,req.session.passwords,"conjuring")
    var flag = req.session.conjuring
    if(flag)
    {
        res.redirect('alreadyFound')
    }
    else
    {
        res.redirect('AddedWatchlist')
    }
})

app.post('/conjuringR',function(req,res){

    deleteFromWatch(req.session.user,req.session.passwords,"conjuring")
    res.redirect('RemovedFromWatchlist')

})

//Fight club

app.get('/fightclub',function(req,res){
    res.render("fightclub");
});

app.post('/fightclub',function(req,res){

    req.session.fightclub = Check(req.session.user,req.session.passwords,"fightclub")
    var flag = req.session.fightclub
    if(flag)
    {
        res.redirect('alreadyFound')
    }
    else
    {
        res.redirect('AddedWatchlist')
    }
    
})

app.post('/fightclubR',function(req,res){

    deleteFromWatch(req.session.user,req.session.passwords,"fightclub")
    res.redirect('RemovedFromWatchlist')

})

//Dark knight

app.get('/darkknight',function(req,res){
    res.render('darkknight')
})

app.post('/darkknight',function(req,res){
    
    req.session.darkknight = Check(req.session.user,req.session.passwords,"darkknight")
    var flag = req.session.darkknight
    if(flag)
    {
        res.redirect('alreadyFound')
    }
    else
    {
        res.redirect('AddedWatchlist')
    }})

app.post('/darkknightR',function(req,res){

    deleteFromWatch(req.session.user,req.session.passwords,"darkknight")
    res.redirect('RemovedFromWatchlist')

})

// Functions used


function Check(user , pass ,movie) {
    var movieexist = true;
    var found1 = false
    var exist = false
    let x = fs.readFileSync('MyDataBase.JSON');
    let y = JSON.parse(x)
    for(var i = 0 ; i < y.length ; i++)
    {
        if(y[i].name == user)
        {
            if(y[i].pass == pass)
            {
                found1 = true;
                break;
            }
        }
    }
    if(found1)
    {
        for(var j = 0 ; j < y[i].watch.length; j++)
        {
            if(y[i].watch[j] == movie)
            {
                exist = true
                break;
            }
        }
        if(exist == false){
            var l = y[i].watch.length;
            y[i].watch[l] = movie
            var newList = y[i]
            delete(y[i])
            y[i]=newList
            fs.writeFile('MyDataBase.JSON',JSON.stringify(y),finished);
            movieexist = false;
        }
        exist = false
        found1 = false
    }
    return movieexist;
}
function deleteFromWatch(user,pass,movie) {
    let x = fs.readFileSync('MyDataBase.JSON');
    let y = JSON.parse(x)
    for(var i = 0 ; i < y.length ; i++)
    {
        if(y[i].name == user)
        {
            if(y[i].pass == pass)
            {
                for(var j = 0 ; j < y[i].watch.length; j++)
                {
                    if(y[i].watch[j] == movie)
                    {
                        y[i].watch.splice(j,1)
                        fs.writeFile('MyDataBase.JSON',JSON.stringify(y),finished);
                    }
                 }
            }
        }
    }
    
}
function getWatchlist(user,pass) {
    let x = fs.readFileSync('MyDataBase.JSON');
    let y = JSON.parse(x)
    for(var i = 0 ; i < y.length ; i++)
    {
        if(y[i].name == user)
        {
            if(y[i].pass == pass)
            {
                break;
            }
        }
    }
    return(y[i].watch)
}

function getSearch(nth)
{   var mymovie = nth.toLowerCase()
    mymovie.split(" ")
    var movies = ["scream","conjuring","darkknight","fightclub","thegodfather","thegodfather2"]
    for(var i = 0 ; i < movies.length;i++)
    {
        if(movies[i].includes(mymovie))
        {
            return(movies[i])
        }
    }
    return("not found");
}

function finished(err)
{
    
}

var port = process.env.PORT || 3000
app.listen(port,function(){
})

